package com.cg.capstore.repo;

import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.Merchant;
import com.cg.capstore.exception.MerchantAlreadyExist;

public interface IMerchantRepository {

	public Merchant registerMerchant(Merchant merchant)  throws MerchantAlreadyExist;
	public Address addAddress(Address address, String id);

	
}
